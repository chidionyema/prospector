# Marketing Assets

## Listing Page

# FuelClaim

Small fleet operators leave fuel duty unclaimed because the filing costs more attention than
the money appears to be worth. FuelClaim imports the fuel-card statement, matches every
transaction to the vehicle that drew it, and files the reclaim on a monthly cadence.

You are billed a share of what is actually recovered, after it arrives.

## Email

Subject: the fuel duty your fleet is not reclaiming

Most operators between twelve and eighty vehicles never file, because the paperwork is priced
in attention rather than money and the amount is invisible until someone computes it.

Send one statement and we will compute the estimate from your own numbers, before you commit
to anything at all.

## Social

Fuel duty reclaims are not hard. They are tedious, which is worse, because tedious work loses
to whatever else is on the operator's desk that week.

We import the statement, match the transactions, and file on a monthly cadence. Billing is a
share of what arrives, so an unsuccessful reclaim costs the operator nothing at all.