## Architecture

The service ingests fuel-card statements, matches each transaction against the vehicle that
drew it, and files a duty reclaim on the operator's behalf. Ingestion, matching and filing are
three separate workers so that a slow filing queue never blocks intake.

## Data model

An operator owns vehicles; a vehicle accumulates transactions; a reclaim batches transactions
into one submission for one period. Reclaims are immutable once submitted, so a correction is
a new reclaim that supersedes its predecessor rather than an edit to a filed record.

## Interfaces

Statement import accepts the three formats the major fuel-card issuers export. The reclaim
submission is a single form, filed on a monthly cadence, with the evidence bundle attached.

## Build order

Import and matching first, because they are what an operator can evaluate without trusting us
with a filing. Submission last, behind a manual review step until the match rate is proven.