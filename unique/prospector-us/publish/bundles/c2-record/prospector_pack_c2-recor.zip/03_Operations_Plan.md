## Running the service

Two operational loops. The daily loop reconciles imported statements against vehicles and
escalates anything that failed to match. The monthly loop assembles, reviews and files each
reclaim before its deadline.

## Failure handling

An unmatched transaction is never guessed at. It is held, surfaced to the operator, and either
resolved or excluded from the reclaim. A wrong match becomes a wrong filing, and a wrong filing
costs far more than the transaction it would have recovered.

## Staffing

One reviewer can carry the monthly loop for roughly forty operators at the match rates we
target. Review is the constraint on growth, so match-rate work buys capacity directly.

## Compliance

Filings and their evidence are retained for the statutory period. Every submission records who
reviewed it and when, because a reclaim that cannot be explained cannot be defended.