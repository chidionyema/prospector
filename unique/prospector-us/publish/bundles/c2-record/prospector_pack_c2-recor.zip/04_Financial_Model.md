> Every figure below is computed by Python from the assumptions listed at the end of this document. No language model performed any calculation, so the arithmetic is exact — the arithmetic, not the assumptions. Read those before you rely on any number here.

## Financial Model

### Revenue

Revenue is a share of what each operator actually recovers, billed only after the reclaim is
paid out. Recovery scales with fleet size and with the share of transactions matched, so
revenue per operator rises as the matching improves rather than needing a price change.

### Costs

The variable cost is reviewer time in the monthly loop. Infrastructure is immaterial next to
it, so the cost line is effectively a staffing line.

### Payback Period

Acquisition is a referral fee paid once, recovered out of the operator's first successful
reclaim in the common case, and out of the second where the fleet sits at the small end of
the target band.

### LTV:CAC Ratio

Retention is the lever that matters here. An operator who files once through the service and
sees the money arrive has no reason to return to filing it themselves, so lifetime value is
governed by fleet churn rather than by product churn.