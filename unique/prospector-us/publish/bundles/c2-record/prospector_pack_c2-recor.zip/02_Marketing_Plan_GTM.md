## Who buys

Fleet operators running between twelve and eighty vehicles. Below twelve the reclaim is not
worth the operator's attention; above eighty they already employ someone whose job this is.

## How they are reached

Fuel-card issuers and fleet-maintenance providers both sit upstream of the buyer and both
already sell adjacent services. A referral arrangement reaches operators at the point where
they are thinking about fuel cost, which is the only moment the pitch lands.

## What convinces them

A reclaim estimate computed from their own statement, produced before any commitment. The
estimate is the sales asset, because it converts an abstract promise into a number the
operator recognises from their own books.

## Pricing posture

A share of the recovered amount reads as free to a sceptical operator and aligns the incentive
with the outcome. A subscription asks for trust the first conversation has not earned yet.