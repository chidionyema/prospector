# Per-parcel customs broker for DTC importers

_Confidence below is on a 0 to 1 scale: 0 means no retrieved passage spoke to the check either way, and 1 means the retrieved passages settled it outright._

_An AI customs broker that files a CBP entry on every parcel from a direct-to-consumer importer under the new $0 de minimis rule, charging a fee per shipment._

## ✅ PASS

_**Passed 2 of 6 checks.** 4 could not be settled either way — “Is someone already doing this well?”, “Can the customer afford it?”, “Can you actually reach the customer?” and “Is it legal?”. We are listing it anyway, and every verdict below is shown in full, so you can disagree with us before you spend anything._

### Why this is possible now
Trump's May 2025 executive order ended the $800 de minimis exemption that had let cross-border ecommerce skip customs entirely. CBP now requires formal or informal entry, HS classification, and duty payment on every parcel from overseas. The volume of DTC parcels that previously flowed under de minimis is massive, and the existing customs brokerage industry is built around $50,000 bulk shipments, not $12 phone cases.

### Who pays for it
DTC ecommerce brands on Shopify, Amazon FBA sellers importing from China or Mexico, and cross-border dropshippers who now face customs paperwork on every overseas shipment they bring in.

### How it works
DTC ecommerce brands and Amazon FBA sellers importing from overseas used to ship under the $800 de minimis exemption: no customs paperwork, no duties, no broker. In May 2025 the Trump administration ended that exemption. Now every parcel from China, Mexico or Vietnam needs a CBP (Customs and Border Protection) entry, an HS (Harmonized System) code classification, and duty paid in advance. Customs brokers historically serve bulk importers at $200+ per entry, and the math does not work for a $12 phone case.

This combines three signals, the new tariff policy, the cross-border DTC boom, and large multimodal models, into a new category: a per-parcel AI customs broker. A seller sends the broker the SKU list, an image, or an API feed from Shopify or Amazon. The broker's model classifies the HS code, drafts the entry, screens for sanctions and country-of-origin rules, holds the customs bond, indemnifies the shipment, and files via ACE (Automated Commercial Environment) on the seller's behalf. The broker charges $1.50 to $3.00 per parcel released, paid only when CBP releases the shipment.

Proprietary data compounds with every cleared parcel. Each classified SKU trains the next classification, and each successful entry sharpens the broker's risk model for the surety (the insurance that backs the duty payment). CBP's free ACE Portal lets a seller file alone, but the regulator cannot act as a broker, cannot aggregate bonds on the seller's behalf, cannot indemnify a parcel, and cannot serve the seller adversarially if CBP disputes the entry. Flexport and Zonos serve B2B and duty display respectively, not per-parcel DTC filings; their cost structure (account managers, B2B overhead) cannot match a $2 per-parcel fee.

---
## What we checked

### ✅ Will this still be worth money later?

**Yes — the sources back this.** Confidence 0.52. *(check: `value_durability`)*

Multiple passages confirm the $800 de minimis exemption is no longer available for most low-value US imports, and that this 'fundamentally chang[es] the economics of shipping individual parcels directly from overseas to U.S. consumers', with cross-border sellers now rethinking how they import; a trade court has upheld the early end of the exemption, so the change is holding up rather than being reversed.

**Sources used:** [ufreight.com](https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/), [youtube.com](https://www.youtube.com/watch?v=8u7hz-1PPss), [mezha.net](https://mezha.net/eng/bukvy/18a803db_us_trade_court/), [greenworldwide.com](https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)

**What those sources said:**
- *“Discover the changes to the de minimis exemption and how it affects duty-free textile and apparel imports from China.One of the key changes involves prohibiting goods subject to major trade actions, including Section 301 tariffs, from qualifying for de minimis entry.”* — [greenworldwide.com](https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)
- *“minimis exemption suspended and Amazon AWD introducing new product restrictions from July 31, 2026, cross-border eCommerce sellers are rethinking how they import, store and fulfill inventory in the U.S. The U.S. eCommerce logistics landscape is entering a new phase.”* — [ufreight.com](https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/)
- *“2026, 08:05 Record Rainfall Floods Japan, Killing Four and Stranding 7,000 Airport Passengers 14 aug 2026, 07:52 Ukraine Reports Russia Lost 1,470 Troops in One Day 14 aug 2026, 07:22 Ukraine’s SBU Issues In Absentia Suspicion Against Prison Inspector Over Alleged POW Abuse 14 aug 2026, 07:15 China…”* — [mezha.net](https://mezha.net/eng/bukvy/18a803db_us_trade_court/)
- *“EU abolishes the €150 de minimis customs duty exemption US suspends the $800 de minimis exemption for non-postal imports EU approves implementation of the US-EU Turnberry agreement Airbus-Boeing tariff suspension extended Fresh US tariff threats linked to digital services...”* — [youtube.com](https://www.youtube.com/watch?v=8u7hz-1PPss)

### ⚠️ Is someone already doing this well?

**Can't tell — the sources don't say.** Confidence 0.73. *(check: `incumbency`)*

The supplied passages are about a German footballer, dictionary definitions of the word "per", medical continuing-education courses, and Netflix streaming — none of them mention customs brokerage, import filings, parcel shipping, or any company serving small importers. Nothing here says whether any provider already handles per-parcel customs filing for direct-to-consumer sellers, so the question of an established player cannot be judged on this evidence.

**Sources used:** [en.wikipedia.org](https://en.wikipedia.org/wiki/Per_Mertesacker), [merriam-webster.com](https://www.merriam-webster.com/dictionary/per), [gotoper.com](https://www.gotoper.com/), [dictionary.com](https://www.dictionary.com/browse/per), [merriam-webster.com](https://www.merriam-webster.com/thesaurus/per), [ja.wikipedia.org](https://ja.wikipedia.org/wiki/Netflix), [netflix.com](https://www.netflix.com/), [netflix.com](https://www.netflix.com/jp/), [help.netflix.com](https://help.netflix.com/ja), [help.netflix.com](https://help.netflix.com/ja/node/101653)

**What those sources said:**
- *“From Wikipedia, the free encyclopedia German association football player (born 1984) Per Mertesacker Mertesacker with Arsenal in 2018Personal informationFull name Per Mertesacker[1]Date of birth (1984-09-29) 29 September 1984 (age 41)[2]Place of birth Hanover,[3] West GermanyHeight 1.98 m (6 ft 6…”* — [en.wikipedia.org](https://en.wikipedia.org/wiki/Per_Mertesacker)
- *“3 days ago · The meaning of PER is by the means or agency of: through. How to use per in a sentence. Using Per as a Preposition: Usage Guide.”* — [merriam-webster.com](https://www.merriam-webster.com/dictionary/per)
- *“Accredited CE/CMEExplore. Engage.Educate.Evidence-based continuing education designed by leading faculty — in-person events, live webcasts, and on-demand courses that translate directly to better patient care.Create an AccountContact Us/FAQsAlready have an account?”* — [gotoper.com](https://www.gotoper.com/)
- *“second Per. sing. of the imperative. From Elements of Gaelic Grammar by Alexander Stewart Per. & my nephew & the “Process” have made a great stride forward. From The Letters of Anne Gilchrist and Walt Whitman by Anne Burrows Gilchrist States that maintain a PER of 6 percent or lower will not have…”* — [dictionary.com](https://www.dictionary.com/browse/per)
- *“1 day ago · Synonyms for PER: via, by, with, through, in, by dint of, by means of, by virtue of; Antonyms of PER: together, collectively, altogether, aggregately”* — [merriam-webster.com](https://www.merriam-webster.com/thesaurus/per)
- *“2024年1月23日、プロレス団体のWWEと契約を結び、2025年1月以降の複数国でのWWE・ロウの放送権を得たことを発表した[11]。当初はアメリカ、カナダ、イギリス、ラテンアメリカで配信され、その後は他の地域でも配信される。アメリカ国外では、WWEの他の番組（ロウ、スマックダウン、NXT、ペイ・パー・ビュー、ドキュメンタリー)の配信権も得た[12]。Netflixは10年間にわたり毎年5億ドルを支払う[13][14][15]。 アメリカンフットボール…”* — [ja.wikipedia.org](https://ja.wikipedia.org/wiki/Netflix)
- *“Netflix United Kingdom – Watch series online, watch films onlineUnlimited films, series and moreStarts at £5.99. Cancel at any time.Ready to watch? Enter your email to create or restart your membership.Email addressThe Netflix you love for just £5.99.Get our most affordable, advert-supported…”* — [netflix.com](https://www.netflix.com/)
- *“Netflix United Kingdom – Watch series online, watch films onlineUnlimited films, series and moreStarts at £5.99. Cancel at any time.Ready to watch? Enter your email to create or restart your membership.Email addressThe Netflix you love for just £5.99.Get our most affordable, advert-supported…”* — [netflix.com](https://www.netflix.com/jp/)
- *“Netflixの登録方法や利用の仕方を確認できます。 アカウントの問題に関するサポート、トラブルシューティング、よくある質問について確認できます。”* — [help.netflix.com](https://help.netflix.com/ja)
- *“Netflixアプリをダウンロードする方法 | Netflixヘルプセンター ヘルプセンター Netflixに登録 ログイン ヘルプセンター ヘルプホームへ戻る Netflixアプリをダウンロードする方法…”* — [help.netflix.com](https://help.netflix.com/ja/node/101653)

### ⚠️ Can the customer afford it?

**Can't tell — the sources don't say.** Confidence 0.52. *(check: `payer_solvency`)*

The passages describe cross-border DTC sellers facing new duty treatment on small parcels, razor-thin B2C parcel margins, and merchants already spending on workarounds like domestic fulfillment and DDP terms, plus general ecommerce revenue scale and one seller with $20K monthly store revenue, but none of these state what an importing seller actually pays for customs or compliance services, so a £199.99 one-off outlay cannot be judged against any observed spending.

**Sources used:** [thelogisticnews.com](https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/), [channelengine.com](https://www.channelengine.com/en/blog/worlds-top-marketplaces), [linkedin.com](https://www.linkedin.com/posts/nimisha-agarwal-619851171_ecommercemetrics-businessstrategy-dtc-activity-7422494400489914368-Bh8h), [simplyduty.com](https://www.simplyduty.com/import-calculator/)

**What those sources said:**
- *“ecommerce is growing its share of retail sales across all markets, the organic growth potential looks very appealing.Let’s look at the figures: in 2025, global retail ecommerce sales are expected to reach about $7.4 trillion, up sharply from roughly $6.1 trillion in 2023, and accounting for over…”* — [channelengine.com](https://www.channelengine.com/en/blog/worlds-top-marketplaces)
- *“tariff treatment on small parcels that formerly sailed under de minimis thresholds is reshaping unit economics for cross-border DTC sellers. Carriers now face longer clearance cycles, more exceptions, and customer-service overhead as duties surprise end-buyers.”* — [thelogisticnews.com](https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/)
- *“#EcommerceBusiness #Ecommerce2026 #OnlineBusinessGrowth #DigitalMarketing #SmallBusinessTips #BusinessStrategy #CustomerTrust #BrandBuilding #DataDrivenMarketing #MarketingSolutions 2 Comments Like Comment To view or add a comment, sign in Ecom Tribe 23 followers 5mo Report this post Why do so many…”* — [linkedin.com](https://www.linkedin.com/posts/nimisha-agarwal-619851171_ecommercemetrics-businessstrategy-dtc-activity-7422494400489914368-Bh8h)
- *“Import Duty Calculator - SimplyDuty Press enter to begin your search No menu assigned! Duty Calculator Import Duty & Tax Calculations Use this quick tool to calculate import duty & taxes for hundreds of destinations worldwide.”* — [simplyduty.com](https://www.simplyduty.com/import-calculator/)

### ⚠️ Can you actually reach the customer?

**Can't tell — the sources don't say.** Confidence 0.58. *(check: `distribution`)*

The passages show that Shopify has an app store where third-party tools reach merchants and that tens of thousands of independent Amazon sellers operate at scale, but none of them says anything about how importers find, buy, or connect a customs filing service, nor whether such a service can be listed or integrated through these channels. Nothing here addresses US import filing at all — the only customs material is about the EU tariff system and Indian export promotion.

**Sources used:** [linnworks.com](https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/), [apps.shopify.com](https://apps.shopify.com/), [sellercentral.amazon.com](https://sellercentral.amazon.com/), [taxation-customs.ec.europa.eu](https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en), [indiantradeportal.in](https://indiantradeportal.in/)

**What those sources said:**
- *“Customs Tariff (CCT) is a system of tariffs applied to goods imported into the EU from non-EU countries. Within the EU, goods can circulate freely thanks to the EU’s internal market.”* — [taxation-customs.ec.europa.eu](https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en)
- *“Linnworks Shopify integration is now on the Shopify App Store — streamline orders, stock, listings & shipping with one of ecommerce’s most powerful combos.”* — [linnworks.com](https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/)
- *“2025Export Profiles of Indian StatesState Export Profile 2025-26Banking Regulations for Indian ExportersRegister for Weekly Interaction with Dr. Ajay Sahai, DG & CEO, FIEOForeign Trade Policy of IndiaIndian Customs ManualIndian Missions AbroadBusiness OpportunitiesGlobal Trade Services (GTS)Indian…”* — [indiantradeportal.in](https://indiantradeportal.in/)
- *“integration. Learn moreOpens in new window CWILL Order Tracking 5.0 out of 5 stars (2,875) 2875 total reviews • Free plan available Parcel Panel: track order tracker to cut WISMOs & boost sales Meets our highest standards for performance, design, and integration.”* — [apps.shopify.com](https://apps.shopify.com/)
- *“Amazon selling account Sign up* Get 10% back on your first $50,000 in branded sales In 2024, more than 55,000 independent sellers generated over $1 million in sales.¹ New Seller Incentives Get started with $50,000 in incentives Ready to sell with Amazon?”* — [sellercentral.amazon.com](https://sellercentral.amazon.com/)

### ⚠️ Is it legal?

**Can't tell — the sources don't say.** Confidence 0.54. *(check: `legality`)*

The passages describe how U.S. customs brokers are regulated — license exams, permit and exam fees, continuing-education requirements, triennial reports, and rules on dealing with unlicensed parties — and confirm that CBP runs electronic filing systems brokers use; none of this forbids filing entries for small parcels or charging a per-shipment fee, so nothing here shows the business requires breaking a law or a contract.

**Sources used:** [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/frequently-asked-questions), [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/fees), [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/continuing-education/information-for-educators-licensed-customs-requirement), [cbp.gov](https://www.cbp.gov/document/publications/past-customs-broker-license-examinations-answer-keys), [ace.cbp.gov](https://ace.cbp.gov/s/), [cbp.gov](https://www.cbp.gov/document/guidance/ace-basics-portal-account), [ace.cbp.gov](https://ace.cbp.gov/s/login/?ec=302&startURL=%2Fs%2F)

**What those sources said:**
- *“licensed individuals and organizations must file a triennial report. If an individual is working for a licensed customs broker and transacting customs business on behalf of the licensed customs broker employer, the individual does not need a permit.”* — [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/frequently-asked-questions)
- *“Customs Brokers Customs Broker Fees Customs Broker Fees As of October 1, 2025, the annual permit user fee increases to $185.38 per Federal Register Notice (90 FR 34665) dated 7/22/2024.”* — [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/fees)
- *“Customs Brokers Customs Broker Continuing Education Information For Educators Providing Continuing Education For Customs Brokers Information For Educators Providing Continuing Education for Customs Brokers U.S. Customs and Border Protection (CBP) published the Continuing Education for Licensed…”* — [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/continuing-education/information-for-educators-licensed-customs-requirement)
- *“Automated Broker Interface der Automatisierten Handelsumgebung (ABI/ACE).”* — [ace.cbp.gov](https://ace.cbp.gov/s/)
- *“Provides an overview of ACE Portal account structures, user types, along with reminders.Share sensitive information only on official, secure websites.”* — [cbp.gov](https://www.cbp.gov/document/guidance/ace-basics-portal-account)
- *“Home Newsroom Documents Library Past Customs Broker License Examinations & Answer Keys Past Customs Broker License Examinations & Answer Keys Downloadable recent exams and answer keys.Note: Answer keys are not modified post-appeal decisions Attachment Ext.”* — [cbp.gov](https://www.cbp.gov/document/publications/past-customs-broker-license-examinations-answer-keys)
- *“Welcome to the ACE Secure Data Portal. Facilitating legitimate trade by automating tools and information. For Returning Users. Enter your email and password to proceed.”* — [ace.cbp.gov](https://ace.cbp.gov/s/login/?ec=302&startURL=%2Fs%2F)

### ✅ Is the problem real?

**Yes — the sources back this.** Confidence 0.58. *(check: `pain_reality`)*

The passages state that the $800 duty-free allowance for small parcels was eliminated — May 2025 for China/Hong Kong and August 29, 2025 for all countries — so every package now faces tariffs and customs clearance instead of flowing through untouched, and one source describes the effect on sellers as 'immediate and severe,' with roughly 4 million more parcels pushed into the formal process.

**Sources used:** [mywifequitherjob.com](https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/), [blogs.tradlinx.com](https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/), [cleverific.com](https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide), [fashionindex.com](https://www.fashionindex.com/blog/de-minimis-ended), [en.wikipedia.org](https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection)

**What those sources said:**
- *“China for 18 years running BumblebeeLinens.com, and here is exactly what changed, who wins, who loses, and what you need to do now.Get My Free Mini Course On How To Start A Successful Ecommerce StoreIf you are interested in starting an ecommerce business, I put together a comprehensive package of…”* — [mywifequitherjob.com](https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/)
- *“customs. The exception was put into place to save the time and money spent on collecting relatively small amounts by customs. But, what was intended as administrative efficiency became the foundation for entire business models. The timeline to remove this loophole was accelerated.”* — [fashionindex.com](https://www.fashionindex.com/blog/de-minimis-ended)
- *“Customs and Border Protection (CBP). Most of these parcels originated from China and Hong Kong, accounting for nearly two-thirds of total volume prior to May 2025. But the very features that made the exemption efficient also made it vulnerable—offering a loophole for tariff evasion, counterfeit…”* — [blogs.tradlinx.com](https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/)
- *“2025De Minimis is ending: How will it impact your ecommerce business?Cleverific TeamshippingThe $800 de minimis threshold that enabled direct-shipping from overseas ends on different dates: August 29, 2025 for most countries, November 9, 2025 for China.Here's how this affects different types of…”* — [cleverific.com](https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide)
- *“importers use "reasonable care" in making entry and providing the initial classification and appraisement, establishing a "shared responsibility" between customs and importers, thus allowing customs to rely on the accuracy of the information submitted and streamline entry procedures.”* — [en.wikipedia.org](https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection)

---
## How it scored

**Overall: 2.5500** (each line is rated out of 5, then weighted)

| What we rated | Score | Why |
|---------------|------:|-----|
| How badly it hurts (`pain_acuity`) | 4/5 | The passages confirm the $800 de minimis exemption was eliminated for China in May 2025 and for all countries by August 2025, pushing roughly 4 million additional parcels into formal CBP clearance with 'immediate and severe' impact on sellers. The regulatory change is real, dated, and upheld by the U.S. Court of International Trade. The pain is acute because every parcel now requires an entry that was previously unnecessary. |
| How provable the money is (`money_provability`) | 2/5 | The price anchors show $200–$500 per CBP entry for bulk vehicle/freight shipments, which bounds the incumbent cost the candidate claims to undercut, but no passage states what a DTC parcel importer actually pays or would pay today for per-parcel filing. The $40.27 figure is a government application fee, not a broker service price. No evidence anchors willingness to pay $1.50–$3.00 per parcel against any observed DTC importer spending. |
| How much one person can automate (`automatability`) | 3/5 | Current multimodal models can classify products into HS codes at reasonable accuracy for common categories, and ACE filing, duty calculation, and sanctions screening are already electronic processes described in the passages. However, the passages note that HS classification is 'difficult and expensive to implement and requires extensive training' with codes that are 'discontinued or merged every five years', and a licensed customs broker is required to sign entries. Edge cases—disputes, exams, country-of-origin determinations, corrections—still require human brokerage judgment. Today this is roughly half automatable, not fully. |
| How easy buyers are to reach (`distribution`) | 2/5 | The passages show Shopify operates an app store where third-party tools reach merchants and that tens of thousands of Amazon sellers operate at scale, but none describes how importers discover, evaluate, or connect a per-parcel customs filing service. No passage identifies a viable go-to-market channel for reaching DTC sellers who now need this filing at scale. |
| How hard it is to copy (`defensibility`) | 2/5 | No passage identifies any provider already serving per-parcel customs filing for DTC importers, so the competitive landscape cannot be assessed. The candidate's claim that Flexport and Zonos cannot serve this segment is neither confirmed nor refuted by the evidence. The proprietary data moat from accumulated HS classifications is plausible but unevidenced; the regulatory window could close or attract well-funded incumbents. |
| How buildable it is (`build_feasibility`) | 2/5 | The passages confirm CBP's ACE electronic filing system exists and is used by brokers, and that broker licensing involves exams, permits, and continuing education, but no passage addresses whether a new entrant can obtain broker licensing promptly, secure surety underwriting for thousands of small importers, or build HS classification accurate enough at the 10-digit level to file without human review. The construction path includes regulatory and insurance dependencies that the evidence does not validate as achievable. |

---
## Why this passed

Survived all gates; composite 2.5500; 2 grounded-supported check(s) (moat grounded: 1).

---
## Every source we used

Every claim above traces back to one of these. Follow any of them and check us. Where a page has since moved or gone, the archived copy is the same text we read, captured on the day we read it.

### 1. greenworldwide.com
**URL:** [https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block](https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260814171612/https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)

> Discover the changes to the de minimis exemption and how it affects duty-free textile and apparel imports from China.One of the key changes involves prohibiting goods subject to major trade actions, including Section 301 tariffs, from qualifying for de minimis entry.

### 2. ufreight.com
**URL:** [https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/](https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260814082004/https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/)

> minimis exemption suspended and Amazon AWD introducing new product restrictions from July 31, 2026, cross-border eCommerce sellers are rethinking how they import, store and fulfill inventory in the U.S. The U.S. eCommerce logistics landscape is entering a new phase. The long-standing US$800 de minimis exemption is no longer available for most low-value imports, fundamentally changing the economics of shipping individual parcels directly from overseas to U.S. consumers.

### 3. mezha.net
**URL:** [https://mezha.net/eng/bukvy/18a803db_us_trade_court/](https://mezha.net/eng/bukvy/18a803db_us_trade_court/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260814082034/https://mezha.net/eng/bukvy/18a803db_us_trade_court/)

### 4. youtube.com — user-generated post
**URL:** [https://www.youtube.com/watch?v=8u7hz-1PPss](https://www.youtube.com/watch?v=8u7hz-1PPss)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260814171709/https://www.youtube.com/watch?v=8u7hz-1PPss)

### 5. en.wikipedia.org — encyclopaedia summary
**URL:** [https://en.wikipedia.org/wiki/Per_Mertesacker](https://en.wikipedia.org/wiki/Per_Mertesacker)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260715164047/https://en.wikipedia.org/wiki/Per_Mertesacker)

### 6. merriam-webster.com — dictionary or reference entry
**URL:** [https://www.merriam-webster.com/dictionary/per](https://www.merriam-webster.com/dictionary/per)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260518103320/https://www.merriam-webster.com/dictionary/per)

> 3 days ago · The meaning of PER is by the means or agency of: through. How to use per in a sentence. Using Per as a Preposition: Usage Guide.

### 7. gotoper.com
**URL:** [https://www.gotoper.com/](https://www.gotoper.com/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260208024544/https://www.gotoper.com/)

> Accredited CE/CMEExplore. Engage.Educate.Evidence-based continuing education designed by leading faculty — in-person events, live webcasts, and on-demand courses that translate directly to better patient care.Create an AccountContact Us/FAQsAlready have an account?

### 8. dictionary.com — dictionary or reference entry
**URL:** [https://www.dictionary.com/browse/per](https://www.dictionary.com/browse/per)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260308203715/https://www.dictionary.com/browse/per)

> second Per. sing. of the imperative. From Elements of Gaelic Grammar by Alexander Stewart Per. & my nephew & the “Process” have made a great stride forward. From The Letters of Anne Gilchrist and Walt Whitman by Anne Burrows Gilchrist States that maintain a PER of 6 percent or lower will not have to pay into SNAP, with the federal government continuing to pay 100 percent of the program.

### 9. merriam-webster.com — dictionary or reference entry
**URL:** [https://www.merriam-webster.com/thesaurus/per](https://www.merriam-webster.com/thesaurus/per)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260518122905/https://www.merriam-webster.com/thesaurus/per)

> 1 day ago · Synonyms for PER: via, by, with, through, in, by dint of, by means of, by virtue of; Antonyms of PER: together, collectively, altogether, aggregately

### 10. ja.wikipedia.org — encyclopaedia summary
**URL:** [https://ja.wikipedia.org/wiki/Netflix](https://ja.wikipedia.org/wiki/Netflix)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260729152051/https://ja.wikipedia.org/wiki/Netflix)

### 11. netflix.com
**URL:** [https://www.netflix.com/](https://www.netflix.com/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260814131335/https://www.netflix.com/)

> Netflix United Kingdom – Watch series online, watch films onlineUnlimited films, series and moreStarts at £5.99. Cancel at any time.Ready to watch?

### 12. netflix.com
**URL:** [https://www.netflix.com/jp/](https://www.netflix.com/jp/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260811053824/https://netflix.com/jp/)

> Netflix United Kingdom – Watch series online, watch films onlineUnlimited films, series and moreStarts at £5.99. Cancel at any time.Ready to watch?

### 13. help.netflix.com
**URL:** [https://help.netflix.com/ja](https://help.netflix.com/ja)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260809230218/https://help.netflix.com/ja)

> Netflixの登録方法や利用の仕方を確認できます。 アカウントの問題に関するサポート、トラブルシューティング、よくある質問について確認できます。

### 14. help.netflix.com
**URL:** [https://help.netflix.com/ja/node/101653](https://help.netflix.com/ja/node/101653)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260521082431/https://help.netflix.com/ja/node/101653)

### 15. channelengine.com
**URL:** [https://www.channelengine.com/en/blog/worlds-top-marketplaces](https://www.channelengine.com/en/blog/worlds-top-marketplaces)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260722185636/https://www.channelengine.com/en/blog/worlds-top-marketplaces)

> ecommerce is growing its share of retail sales across all markets, the organic growth potential looks very appealing.Let’s look at the figures: in 2025, global retail ecommerce sales are expected to reach about $7.4 trillion, up sharply from roughly $6.1 trillion in 2023, and accounting for over 20% of total retail sales worldwide.

### 16. thelogisticnews.com
**URL:** [https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/](https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260518064133/https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/)

> tariff treatment on small parcels that formerly sailed under de minimis thresholds is reshaping unit economics for cross-border DTC sellers. Carriers now face longer clearance cycles, more exceptions, and customer-service overhead as duties surprise end-buyers. Merchants are testing new playbooks: moving inventory into domestic fulfillment, shifting to DDP terms to reduce cart abandonment, and re-pricing SKUs to defend contribution margins.

### 17. linkedin.com — user-generated post
**URL:** [https://www.linkedin.com/posts/nimisha-agarwal-619851171_ecommercemetrics-businessstrategy-dtc-activity-7422494400489914368-Bh8h](https://www.linkedin.com/posts/nimisha-agarwal-619851171_ecommercemetrics-businessstrategy-dtc-activity-7422494400489914368-Bh8h)

> #EcommerceBusiness #Ecommerce2026 #OnlineBusinessGrowth #DigitalMarketing #SmallBusinessTips #BusinessStrategy #CustomerTrust #BrandBuilding #DataDrivenMarketing #MarketingSolutions 2 Comments Like Comment To view or add a comment, sign in Ecom Tribe 23 followers 5mo Report this post Why do so many ecommerce founders stop scaling the moment things get comfortable? We still remember a call with a client in September—he told us, “Our store’s making $20K a month.

### 18. simplyduty.com
**URL:** [https://www.simplyduty.com/import-calculator/](https://www.simplyduty.com/import-calculator/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260804000752/https://www.simplyduty.com/import-calculator/)

> Import Duty Calculator - SimplyDuty Press enter to begin your search No menu assigned! Duty Calculator Import Duty & Tax Calculations Use this quick tool to calculate import duty & taxes for hundreds of destinations worldwide. Reciprocal Tariff Updates – Calculator Updated 5 Free Calculations Per Day At Simply Duty you get to use our duty calculator free of charge every day!! You only need to upgrade if you want more than 5 calculations per day.

### 19. taxation-customs.ec.europa.eu — official source
**URL:** [https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en](https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260605054502/https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en)

> Customs Tariff (CCT) is a system of tariffs applied to goods imported into the EU from non-EU countries. Within the EU, goods can circulate freely thanks to the EU’s internal market. The tariff upholds the principle that domestic producers in the EU should compete fairly and on equal terms with manufacturers exporting from other countries or territories within the internal market.

### 20. linnworks.com
**URL:** [https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/](https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20240519055703/https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/)

> Linnworks Shopify integration is now on the Shopify App Store — streamline orders, stock, listings & shipping with one of ecommerce’s most powerful combos.

### 21. indiantradeportal.in
**URL:** [https://indiantradeportal.in/](https://indiantradeportal.in/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260515043151/https://indiantradeportal.in/)

### 22. apps.shopify.com
**URL:** [https://apps.shopify.com/](https://apps.shopify.com/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260811154957/https://apps.shopify.com/)

> integration. Learn moreOpens in new window CWILL Order Tracking 5.0 out of 5 stars (2,875) 2875 total reviews • Free plan available Parcel Panel: track order tracker to cut WISMOs & boost sales Meets our highest standards for performance, design, and integration.

### 23. sellercentral.amazon.com
**URL:** [https://sellercentral.amazon.com/](https://sellercentral.amazon.com/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260806194730/https://sellercentral.amazon.com/)

> Amazon selling account Sign up* Get 10% back on your first $50,000 in branded sales In 2024, more than 55,000 independent sellers generated over $1 million in sales.¹ New Seller Incentives Get started with $50,000 in incentives Ready to sell with Amazon? As a new seller, you can take advantage of a series of incentives.

### 24. cbp.gov — official source
**URL:** [https://www.cbp.gov/trade/programs-administration/customs-brokers/frequently-asked-questions](https://www.cbp.gov/trade/programs-administration/customs-brokers/frequently-asked-questions)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260803215030/https://www.cbp.gov/trade/programs-administration/customs-brokers/frequently-asked-questions)

> licensed individuals and organizations must file a triennial report. If an individual is working for a licensed customs broker and transacting customs business on behalf of the licensed customs broker employer, the individual does not need a permit. The Final Rule and the transition to a national permit structure does not have any effect on the statement generation and payment process.

### 25. cbp.gov — official source
**URL:** [https://www.cbp.gov/trade/programs-administration/customs-brokers/fees](https://www.cbp.gov/trade/programs-administration/customs-brokers/fees)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260803215032/https://www.cbp.gov/trade/programs-administration/customs-brokers/fees)

> Customs Brokers Customs Broker Fees Customs Broker Fees As of October 1, 2025, the annual permit user fee increases to $185.38 per Federal Register Notice (90 FR 34665) dated 7/22/2024. The due date for payment of the 2026 user fee will be published in the Federal Register at least 60 days prior to the due date.

### 26. cbp.gov — official source
**URL:** [https://www.cbp.gov/trade/programs-administration/customs-brokers/continuing-education/information-for-educators-licensed-customs-requirement](https://www.cbp.gov/trade/programs-administration/customs-brokers/continuing-education/information-for-educators-licensed-customs-requirement)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260621222005/https://www.cbp.gov/trade/programs-administration/customs-brokers/continuing-education/information-for-educators-licensed-customs-requirement)

### 27. ace.cbp.gov — official source
**URL:** [https://ace.cbp.gov/s/](https://ace.cbp.gov/s/)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260803215817/https://ace.cbp.gov/s/)

> Automated Broker Interface der Automatisierten Handelsumgebung (ABI/ACE).

### 28. cbp.gov — official source
**URL:** [https://www.cbp.gov/document/guidance/ace-basics-portal-account](https://www.cbp.gov/document/guidance/ace-basics-portal-account)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260809195758/http://www.cbp.gov/document/guidance/ace-basics-portal-account)

> Provides an overview of ACE Portal account structures, user types, along with reminders.Share sensitive information only on official, secure websites.

### 29. cbp.gov — official source
**URL:** [https://www.cbp.gov/document/publications/past-customs-broker-license-examinations-answer-keys](https://www.cbp.gov/document/publications/past-customs-broker-license-examinations-answer-keys)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260621222325/https://www.cbp.gov/document/publications/past-customs-broker-license-examinations-answer-keys)

> Home Newsroom Documents Library Past Customs Broker License Examinations & Answer Keys Past Customs Broker License Examinations & Answer Keys Downloadable recent exams and answer keys.Note: Answer keys are not modified post-appeal decisions Attachment Ext.

### 30. ace.cbp.gov — official source
**URL:** [https://ace.cbp.gov/s/login/?ec=302&startURL=%2Fs%2F](https://ace.cbp.gov/s/login/?ec=302&startURL=%2Fs%2F)
**Archived copy:** [permanent snapshot](https://web.archive.org/web/20260803215819/https://ace.cbp.gov/s/login/?ec=302&startURL=%2Fs%2F)

> Welcome to the ACE Secure Data Portal. Facilitating legitimate trade by automating tools and information. For Returning Users. Enter your email and password to proceed.

### 31. mywifequitherjob.com
**URL:** [https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/](https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/)

> China for 18 years running BumblebeeLinens.com, and here is exactly what changed, who wins, who loses, and what you need to do now.Get My Free Mini Course On How To Start A Successful Ecommerce StoreIf you are interested in starting an ecommerce business, I put together a comprehensive package of resources that will help you launch your own online store from complete scratch.

### 32. fashionindex.com
**URL:** [https://www.fashionindex.com/blog/de-minimis-ended](https://www.fashionindex.com/blog/de-minimis-ended)

> customs. The exception was put into place to save the time and money spent on collecting relatively small amounts by customs. But, what was intended as administrative efficiency became the foundation for entire business models. The timeline to remove this loophole was accelerated. Under the Biden Administration, de minimis was originally set to be phased out in July 2027, but it was moved up as part of broader trade policy changed.

### 33. blogs.tradlinx.com
**URL:** [https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/](https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/)

> Customs and Border Protection (CBP). Most of these parcels originated from China and Hong Kong, accounting for nearly two-thirds of total volume prior to May 2025. But the very features that made the exemption efficient also made it vulnerable—offering a loophole for tariff evasion, counterfeit goods, and reduced enforcement visibility. That vulnerability is now at the heart of the U.S. government’s decision to shut it down completely. What’s Changing and When?

### 34. cleverific.com
**URL:** [https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide](https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide)

> 2025De Minimis is ending: How will it impact your ecommerce business?Cleverific TeamshippingThe $800 de minimis threshold that enabled direct-shipping from overseas ends on different dates: August 29, 2025 for most countries, November 9, 2025 for China.Here's how this affects different types of ecommerce businesses.The United States is ending the de minimis exemption globally. Most countries lose the exemption August 29, 2025, while China received a 90-day extension until November 9, 2025.

### 35. en.wikipedia.org — encyclopaedia summary
**URL:** [https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection](https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection)

> importers use "reasonable care" in making entry and providing the initial classification and appraisement, establishing a "shared responsibility" between customs and importers, thus allowing customs to rely on the accuracy of the information submitted and streamline entry procedures. To the extent that an importer fails to use reasonable care, customs may impose a penalty. U.S. Customs agriculture specialist officers are allowed to issue civil penalties in accordance with CFR 7 & 9.

---
## Run details

- **Market:** us
- **Pack reference:** `25363e54b649587a`
- **Created:** 2026-08-14T08:14:48.696918+00:00
- **Next evidence check:** 2026-09-13

We re-check the evidence behind this pack every 30 days. The date above is when we look again, not a date this stops being true. If a check no longer holds up, we take the pack off sale rather than leave it quietly going out of date.