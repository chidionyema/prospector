# Running a per-parcel customs filing service

## Before you take a single parcel

Filing entries for other people's goods is a licensed activity in the US. Nothing in the evidence behind this pack establishes what licence, company permit, bond or surety you need, how long each takes, or what they cost — treat all of that as **assumption — unverified**. Your first task, before any seller signs anything, is to get those answers in writing from Customs and Border Protection and from a surety, and to date the file. Do not start by "helping sellers file for themselves" as a workaround until a lawyer has told you in writing that this is outside the licensed activity.

## Choose the parcels you will file for

Build for parcels that move by courier, not by post.

A courier parcel under $800 is now treated like a bigger shipment: it needs a full tariff code, an origin declaration and duty paid (source: https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/). That is the exact work you are selling.

Postal is a worse market. It ran on a flat charge of $80 to $200 per item from 29 August 2025 to 28 February 2026, and from 1 March 2026 pays full value-based tariffs (same source). At those levels a $20 item from China shipped by post can land at $100 to $220 all-in (source: https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/). Sellers facing that are often not shipping at all, so there is no parcel for you to file.

Skip sellers who already ship by FedEx, UPS or DHL and already pay duties — little changed for them (same source). Your customer is the one who shipped direct to consumers duty-free and now cannot.

## The daily loop

One queue, three stations.

1. **Intake.** Product details, declared value, origin evidence. No origin evidence, no filing: an origin declaration is a required part of the entry (source: tradlinx, above).
2. **Classify.** The model proposes a tariff code. A person confirms it the first time a product appears, and that decision is stored against the product. Later parcels of the same product from the same seller reuse the confirmed code without a second review.
3. **File and release.** Duty paid, entry filed, seller notified.

Keep the evidence attached to each entry, not in email. Customs expects importers to use reasonable care when making entry and classifying goods, and treats accuracy as a shared responsibility between customs and the importer; it can penalise an importer who falls short (source: https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection). Presenting false information to a customs officer carries criminal penalties of up to two years or a $5,000 fine per violation (same source). Your defence, and your seller's, is a stored trail per parcel.

## Staffing to the queue

Staff to first sightings, not to parcels. A repeat product costs you compute; a new one costs you a person. Track those two counts separately from week one, because only the first tells you when to hire.

For context on scale: customs was processing over 4 million of these low-value shipments a day, and 83% of them were ecommerce (source: https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide, citing White House data and Congressional Research Service analysis).

## The number to watch weekly

Your fully loaded cost per released parcel: reviewer minutes plus model spend plus duty-handling overhead, divided by parcels released.

The evidence here contains no benchmark for what customs brokers charge per entry, so any price you have seen quoted for this business is **assumption — unverified**. Set your fee from the measured cost, publish it, and revisit it monthly until first-sighting rates settle.

## What ends this business

Sellers consolidating. The pressure is towards bulk importing, US warehousing and third-party fulfilment instead of shipping parcels from overseas, and Amazon's warehousing programme tightens size and weight rules from 31 July 2026 (source: https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/).

So report monthly, per customer, the share of their volume still arriving as individual parcels. A customer whose share is falling is leaving, whatever their satisfaction score says.