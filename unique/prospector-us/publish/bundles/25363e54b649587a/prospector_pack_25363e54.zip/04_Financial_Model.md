> Every figure below is computed by Python from the assumptions listed at the end of this document. No language model performed any calculation, so the arithmetic is exact — the arithmetic, not the assumptions. Read those before you rely on any number here.

## Financial Model

### What it earns

- **Month 1:** $2 × 3 customers = **$7**
- **Month 12:** $2 × 60 customers = **$135**
- **Growth (M1→M12):** 20.0×

### What it keeps after costs

- **Gross margin: 55%** — making and delivering it costs 45% of what you charge
- **Kept per customer: $1.24** a month

### What it costs to win a customer

- **Costs to win one customer: $900**
- **Paid back in: ~727.3 months** ($900 to win a customer ÷ $1.24 kept each month)

### Month one, in and out

- In: $7
- Cost of making and delivering it (45%): $3
- Everything else it takes to run: $14,000
- **Left over: -$13,996**

### What we could not work out

Nothing below was invented to fill a gap. Each one needs a number the evidence behind this idea did not give us, and each is worth pinning down before you commit money:

- Whether buyers pay once or keep paying. Everything about what a customer is worth over time hangs on it, and it was not stated.

### What we assumed

- The buyer is a seller, not a shopper. You charge the direct-to-consumer brand or Amazon seller who imports the goods, not the person who receives the parcel.
- Money comes in per parcel cleared, not per month. A seller who signs up sends parcels for as long as they keep importing, so treat the account as a repeat buyer rather than a subscriber.
- Price: $2.25 for each parcel released by US Customs, the midpoint of the $1.50 to $3.00 range in the idea. Assumption — unverified: no source here prices a per-parcel filing, and the only price anchor in the evidence runs the other way, at $80 to $200 per postal shipment in handling fees during the first phase after the rules changed (source: https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/). That is a fee charged by carriers, not a broker's filing fee, so it caps what a seller will tolerate rather than setting your price.
- Volume per account: 3,000 parcels a year from a typical signed seller. That is the number that turns $2.25 into a real account, and it is the single figure to test before anything else. Assumption — unverified.
- Sign 3 sellers in month one and 60 by month twelve. These are working targets, not a forecast, and they assume you sell hands-on to brands you already know.
- Cost of delivery at 45 cents in every dollar: the model calls that classify each item and draft each filing, the bond and insurance that back the duty payment, and the licensed customs broker whose licence every filing is made under. Assumption — unverified on all three components.
- Fixed costs of $14,000 in month one: a part-time licensed broker, cloud and model bills, and legal work to set up the bond. Assumption — unverified.
- Around $900 to win a seller, and roughly two months from first conversation to first live parcel, because the seller has to trust you with a legal filing they are personally answerable for.
- Demand exists because the $800 duty-free allowance on small parcels is gone for all countries, so every package now faces tariffs and customs clearance (source: https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/). A trade court has upheld the early end of the exemption, so the rule is holding rather than being reversed (source: https://mezha.net/eng/bukvy/18a803db_us_trade_court/).

### Where this is weakest

- No lifetime value figure. Nothing in the evidence says how long a seller keeps importing this way or how many drop out each month, and inventing a drop-out rate to make the sum work would be dishonest. Without it, the $900 cost to win a seller cannot be judged.
- The volume assumption carries the whole model. At $2.25 a parcel, an account sending 300 parcels a year is worth $675 and never pays back the cost of winning it. At 3,000 it is worth $6,750. Everything turns on which of those is true, and no source here settles it.
- The strongest evidence points away from the business. Sellers are moving off direct overseas parcels towards bulk importing and US warehousing (source: https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/). Bulk importers are mostly unaffected by the change (source: https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/). If that shift continues, your parcel count per account shrinks every month while your fixed costs stay.
- Cheap dropshipping may not survive at all. A $20 item from China shipped by post can now cost $100 to $220 once fees apply (source: https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/). Some of the parcels you are counting on will simply stop being sent.
- The gross margin is a guess with legal weight behind it. A wrong classification is not a refund, it is a penalty on the importer, and US Customs can fine an importer who fails to use reasonable care (source: https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection). If you carry that risk for the seller, the true cost of delivery includes claims you cannot price from anything in this evidence.
- Fixed costs are the most fragile number. A licensed broker's pay, the bond, and the insurance behind the duty payment are all unpriced here, and every one of them is a floor you must clear before the first dollar of profit.
- Timing risk on the fee ceiling: full value-based tariffs replaced the flat per-item charge from March 2026 (source: https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/). What a seller will pay a broker moves with what the duty itself costs them, and that has already changed once.