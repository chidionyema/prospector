# Marketing Assets

## How to describe this to someone

_The pitch in plain words. Use it on a landing page, or when someone asks what you are building._

For someone who wants to run a filing service for online sellers, this pack sets out the rule change that created the work, the shape of the service, and the parts nobody has tested yet.

What you get: A plain description of the service: what a seller sends you, what you file with US Customs and Border Protection on their behalf, and what you charge for; An honest list of what the evidence does not cover, including whether sellers will pay an outside filer and how you would reach them

One write-up of the change (fashionindex.com) calls the impact on sellers "immediate and severe", and reports that about 4 million more packages a day are now subject to tariffs and duties that previously went through customs untouched.