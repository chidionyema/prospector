# Executive summary — Per-parcel customs broker for DTC importers

An AI customs broker that files a CBP entry on every parcel from a direct-to-consumer importer under the new $0 de minimis rule, charging a fee per shipment.

## Start here — the next ten minutes

1. Open **QA_Report.md** and pick any claim marked SUPPORTED.
2. Click its source link and find the sentence the claim rests on.
3. If the source does not say what we say it says, stop reading and claim the refund — the pack is wrong and you should not build on it.
4. Then read one line: the payer this was verified against is **DTC ecommerce brands on Shopify, Amazon FBA sellers importing from China or Mexico, and cross-border dropshippers who now face customs paperwork on every overseas shipment they bring in.**. If that is not someone you can reach, the rest of this pack is not for you, and ten minutes is what it cost you to find out.

That is the whole point of the pack: it is checkable. **05_First_Week_Checklist.md** is what to do once it checks out.

## Grounded signals

## What this pack does not claim

No unsourced TAM/SAM figures, guaranteed revenue, or legality shortcuts. If a check was unverifiable, it is absent here on purpose.