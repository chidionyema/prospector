# What you are building

Software that prepares and files a customs entry for one low-value parcel, and charges the seller a fee per parcel released. The whole build hangs on three questions the evidence does not answer, so settle those first.

# Prove you can file before you build anything

These three are assumptions — unverified. Buy a paid hour with a practising customs broker and get written answers:

1. Who is allowed to file — whether your business needs a licensed broker attached to it, and what US Customs and Border Protection (CBP) requires of the software that submits entries.
2. Whether duty must reach CBP before a parcel is released, and who fronts that cash.
3. Whether one bond can stand behind many different sellers' parcels.

If the answer to the first is "licensed broker, certified software", your first hire comes before your first line of code. Do not start the product on the assumption it is not.

# Scope to the parcels that actually changed

Bulk commercial imports mostly did not change: sellers already shipping by courier and paying duty see little difference (source: mywifequitherjob.com). Build only for the parcel flow. Shipments under $800 sent outside the post are now treated like higher-value ones — full tariff code, origin declaration and duty paid, with limited exceptions for travellers and gifts (source: blogs.tradlinx.com) — from 29 August 2025 for most countries and 9 November 2025 for China (source: cleverific.com). Postal parcels ran on a flat charge of $80 to $200 an item to 28 February 2026, with value-based tariffs scheduled from 1 March 2026 (source: blogs.tradlinx.com). That second phase is a scheduled date in the source, not an observed one, so make your software ask which regime a parcel falls under rather than assuming.

# Build the classifier as a catalogue tool, not a parcel tool

Classify a product once and reuse the answer on every parcel carrying it. Take in a spreadsheet of the seller's listings on day one — title, description, materials, photo, country of origin — and automate the feed later. The model must pick a code from a loaded copy of the official US tariff schedule and never write a code string freehand. Anything under your confidence threshold goes to a human reviewer before it is filed.

Give country of origin its own field and its own review step. Goods caught by particular trade actions were barred from the duty-free low-value route (source: greenworldwide.com), so origin decides whether a parcel qualifies at all, not merely what it costs.

# The money path

In the postal channel, duty and the per-item charge are collected before the package ships (source: mywifequitherjob.com). Design for money moving ahead of release: a prepaid seller balance, a hold per parcel, and reconciliation against what CBP actually assessed. Never file against a balance you have not collected. Bill your own fee as a separate line on release.

Build the ledger before the filing feature. A system that cannot say who owes what will not survive its first disputed entry.

# Accuracy is the product, so instrument it

US customs treats getting entries right as a shared responsibility between customs and importers, expects importers to use reasonable care, and penalises those who do not; presenting false information to customs officers carries a maximum of two years in prison, or a $5,000 fine, or both, per violation (source: Wikipedia's article on US Customs and Border Protection). Check that against the statute with your broker before it goes anywhere near a customer contract.

In the build: log every classification with the model version, the evidence it saw and the reviewer who cleared it. Make entries immutable, amended only by a new record. Hold back a test set of real listings whose codes a licensed broker has confirmed, and re-run it on every model change. No outside benchmark exists for this, so the internal one is the only number you will have.

# What sinks this

Volume. CBP processed over 4 million low-value shipments a day, and 83% of low-value imports overall were e-commerce (source: White House and Congressional Research Service data, via cleverific.com) — but both figures describe the rules that have now been removed. One logistics provider says sellers are rethinking how they import, and that the change is pushing them towards bulk importing and US warehousing (source: ufreight.com); that provider sells warehousing, so weigh it accordingly. If that shift is real, parcel counts fall and your revenue falls with them. Track monthly parcel volume across your first ten sellers. That is your market signal, not anyone's forecast.

The legal ground. A trade court upheld the early end of the exemption on 13 August 2026, while importers still wait on Congress's planned final phaseout (source: mezha.net, reporting Reuters). Keep rates, thresholds and dates in tables you can edit in an afternoon, not in code you have to redeploy.