# Your first fortnight — Per-parcel customs broker for DTC importers

An AI customs broker that files a CBP entry on every parcel from a direct-to-consumer importer under the new $0 de minimis rule, charging a fee per shipment.

Ten working days, in order. Every step points at the document in this pack that tells you how, so nothing here needs reading twice.

## Week one — find out whether anybody pays

1. Find five of them and talk to all five: **DTC ecommerce brands on Shopify, Amazon FBA sellers importing from China or Mexico, and cross-border dropshippers who now face customs paperwork on every overseas shipment they bring in.** Not a survey and not a poll — five conversations, in the order you can get them. If you cannot find five in a week, that is the finding, and it cost you a week instead of a year.
2. Put the question we could not answer to them directly: **Is someone already doing this well?** We searched and found nothing that settles it, which is why it sits in *Evidence and Constraints* as an assumption rather than a finding. The other open questions are listed beside it: *Can the customer afford it?*, *Can you actually reach the customer?* and *Is it legal?*. Five buyers can answer in an afternoon what the open web could not.
3. Say the price out loud to those five. It is in *04_Financial_Model.md*, with the arithmetic behind it. Nobody flinching means it is too low; everybody flinching means the model is wrong — and either way you know in week one, for nothing.
4. Pick ONE channel out of *02_Marketing_Plan_GTM.md* and ignore the rest until it works. A plan that runs three channels badly in week one tells you nothing about any of them.

## Week two — put it in front of them

5. Build the smallest version described in *01_Blueprint_BuildSpec.md* — the one that answers whatever your five buyers asked about most — and nothing beyond it.
6. Work through *03_Operations_Plan.md* from “Before you take a single parcel” onwards while there is no customer waiting. Every hour of it is cheaper now than it is the day a real one arrives.
7. Ask one of the five to pay. Today's version, today's price. A yes is the only evidence in this pack that we could not go and get for you.
8. Write down what changed your mind. You now know things about this buyer that nothing we retrieved could tell us, and week three should be built on those, not on this document.

---

Nothing above assumes you finished the step before it perfectly. If week one says no, stop — that is the pack having done its job, and it is why the price is what it is rather than what a month of building would have cost you.
