# Evidence and Constraints

Everything the plans in this pack lean on, for **Per-parcel customs broker for DTC importers**, gathered in one place so you read it once.

The build spec, the go-to-market plan and the operations plan each apply these findings to their own job. None of them re-argues the evidence. It is here.

---

## What we checked, and what it means for you

### Will this still be worth money later?

The evidence backs this up.

Multiple passages confirm the $800 de minimis exemption is no longer available for most low-value US imports, and that this 'fundamentally chang[es] the economics of shipping individual parcels directly from overseas to U.S. consumers', with cross-border sellers now rethinking how they import ([ufreight.com](https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/), [youtube.com](https://www.youtube.com/watch?v=8u7hz-1PPss), [greenworldwide.com](https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)); a trade court has upheld the early end of the exemption, so the change is holding up rather than being reversed ([mezha.net](https://mezha.net/eng/bukvy/18a803db_us_trade_court/)).

Where this came from:

- [greenworldwide.com](https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)
- [ufreight.com](https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/)
- [mezha.net](https://mezha.net/eng/bukvy/18a803db_us_trade_court/)
- [youtube.com](https://www.youtube.com/watch?v=8u7hz-1PPss) — user-generated post

### Is the problem real?

The evidence backs this up.

The passages state that the $800 duty-free allowance for small parcels was eliminated — May 2025 for China/Hong Kong and August 29, 2025 for all countries — so every package now faces tariffs and customs clearance instead of flowing through untouched ([mywifequitherjob.com](https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/))([blogs.tradlinx.com](https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/))([cleverific.com](https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide)), and one source describes the effect on sellers as 'immediate and severe,' with roughly 4 million more parcels pushed into the formal process ([fashionindex.com](https://www.fashionindex.com/blog/de-minimis-ended)).

Where this came from:

- [mywifequitherjob.com](https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/)
- [fashionindex.com](https://www.fashionindex.com/blog/de-minimis-ended)
- [blogs.tradlinx.com](https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/)
- [cleverific.com](https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide)
- [en.wikipedia.org](https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection) — encyclopaedia summary

---

## What we could not prove

These are assumptions, not findings. We searched and did not find enough to rule either way, so they are listed here rather than buried as a caveat in three different plans.

We do not put a price on testing them. Nothing we retrieved tells us what a test costs, and a number we invented would be exactly the thing this pack promises not to do.

### Is someone already doing this well?

The supplied passages are about a German footballer, dictionary definitions of the word "per", medical continuing-education courses, and Netflix streaming — none of them mention customs brokerage, import filings, parcel shipping, or any company serving small importers. Nothing here says whether any provider already handles per-parcel customs filing for direct-to-consumer sellers, so the question of an established player cannot be judged on this evidence.

**What we searched for.** Start here if you want to settle it yourself:

- per parcel customs broker DTC ecommerce Shopify Amazon FBA 2025
- Flexport Zonos per parcel DTC parcel customs brokerage launch 2025

### Can the customer afford it?

The passages describe cross-border DTC sellers facing new duty treatment on small parcels, razor-thin B2C parcel margins, and merchants already spending on workarounds like domestic fulfillment and DDP terms ([thelogisticnews.com](https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/)), plus general ecommerce revenue scale ([channelengine.com](https://www.channelengine.com/en/blog/worlds-top-marketplaces)) and one seller with $20K monthly store revenue ([linkedin.com](https://www.linkedin.com/posts/nimisha-agarwal-619851171_ecommercemetrics-businessstrategy-dtc-activity-7422494400489914368-Bh8h)), but none of these state what an importing seller actually pays for customs or compliance services, so a £199.99 one-off outlay cannot be judged against any observed spending.

**What we searched for.** Start here if you want to settle it yourself:

- DTC ecommerce cross-border China imports market size 2025 Shopify Amazon
- DTC ecommerce seller margins too thin absorb $2 per parcel tariff cost

### Can you actually reach the customer?

The passages show that Shopify has an app store where third-party tools reach merchants ([linnworks.com](https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/), [apps.shopify.com](https://apps.shopify.com/)) and that tens of thousands of independent Amazon sellers operate at scale ([sellercentral.amazon.com](https://sellercentral.amazon.com/)), but none of them says anything about how importers find, buy, or connect a customs filing service, nor whether such a service can be listed or integrated through these channels. Nothing here addresses US import filing at all — the only customs material is about the EU tariff system ([taxation-customs.ec.europa.eu](https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en)) and Indian export promotion ([indiantradeportal.in](https://indiantradeportal.in/)).

**What we searched for.** Start here if you want to settle it yourself:

- Shopify app store customs broker integration tariff duty 2025
- Amazon FBA seller customs broker app marketplace channel

### Is it legal?

The passages describe how U.S. customs brokers are regulated — license exams, permit and exam fees, continuing-education requirements, triennial reports, and rules on dealing with unlicensed parties (efa22eee929ff90a, 1c7a5c0ca74bbf56, b9c4516fe174e093, 2777cc04d642e048) — and confirm that CBP runs electronic filing systems brokers use (7bd8c2da46ea251c, 1b4ffef4e69f8f90, e947d6d25fadb9e7); none of this forbids filing entries for small parcels or charging a per-shipment fee, so nothing here shows the business requires breaking a law or a contract.

**What we searched for.** Start here if you want to settle it yourself:

- customs broker license requirement 19 CFR 111 individual license CBP site:cbp.gov
- customs broker license not required informal entry self-filer ACE portal site:cbp.gov

---

## Every source, once

35 pages, each listed a single time. Where a page is a forum post or a statistics aggregator rather than a primary record, it says so.

- [greenworldwide.com](https://www.greenworldwide.com/rulemaking-will-remove-section-301-tariff-goods-from-de-minimis/?trk=article-ssr-frontend-pulse_little-text-block)
- [ufreight.com](https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/)
- [mezha.net](https://mezha.net/eng/bukvy/18a803db_us_trade_court/)
- [youtube.com](https://www.youtube.com/watch?v=8u7hz-1PPss) — user-generated post
- [en.wikipedia.org](https://en.wikipedia.org/wiki/Per_Mertesacker) — encyclopaedia summary
- [merriam-webster.com](https://www.merriam-webster.com/dictionary/per) — dictionary or reference entry
- [gotoper.com](https://www.gotoper.com/)
- [dictionary.com](https://www.dictionary.com/browse/per) — dictionary or reference entry
- [merriam-webster.com](https://www.merriam-webster.com/thesaurus/per) — dictionary or reference entry
- [ja.wikipedia.org](https://ja.wikipedia.org/wiki/Netflix) — encyclopaedia summary
- [netflix.com](https://www.netflix.com/)
- [netflix.com](https://www.netflix.com/jp/)
- [help.netflix.com](https://help.netflix.com/ja)
- [help.netflix.com](https://help.netflix.com/ja/node/101653)
- [channelengine.com](https://www.channelengine.com/en/blog/worlds-top-marketplaces)
- [thelogisticnews.com](https://thelogisticnews.com/de-minimis-squeeze-parcel-tariffs-put-pressure-on-cross-border-e-commerce-margins/)
- [linkedin.com](https://www.linkedin.com/posts/nimisha-agarwal-619851171_ecommercemetrics-businessstrategy-dtc-activity-7422494400489914368-Bh8h) — user-generated post
- [simplyduty.com](https://www.simplyduty.com/import-calculator/)
- [taxation-customs.ec.europa.eu](https://taxation-customs.ec.europa.eu/customs/common-customs-tariff-cct_en) — official source
- [linnworks.com](https://www.linnworks.com/blog/linnworks-join-the-shopify-appstore/)
- [indiantradeportal.in](https://indiantradeportal.in/)
- [apps.shopify.com](https://apps.shopify.com/)
- [sellercentral.amazon.com](https://sellercentral.amazon.com/)
- [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/frequently-asked-questions) — official source
- [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/fees) — official source
- [cbp.gov](https://www.cbp.gov/trade/programs-administration/customs-brokers/continuing-education/information-for-educators-licensed-customs-requirement) — official source
- [ace.cbp.gov](https://ace.cbp.gov/s/) — official source
- [cbp.gov](https://www.cbp.gov/document/guidance/ace-basics-portal-account) — official source
- [cbp.gov](https://www.cbp.gov/document/publications/past-customs-broker-license-examinations-answer-keys) — official source
- [ace.cbp.gov](https://ace.cbp.gov/s/login/?ec=302&startURL=%2Fs%2F) — official source
- [mywifequitherjob.com](https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/)
- [fashionindex.com](https://www.fashionindex.com/blog/de-minimis-ended)
- [blogs.tradlinx.com](https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/)
- [cleverific.com](https://cleverific.com/blog/de-minimis-ending-ecommerce-impact-guide)
- [en.wikipedia.org](https://en.wikipedia.org/wiki/United_States_Customs_and_Border_Protection) — encyclopaedia summary
