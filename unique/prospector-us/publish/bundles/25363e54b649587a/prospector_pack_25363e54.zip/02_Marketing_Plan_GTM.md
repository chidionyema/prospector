# Sell to the seller who still ships parcels, not the one who ships pallets

Skip anyone already shipping through FedEx or UPS and paying duties. For them, "little changes" — bulk commercial imports were mostly unaffected (source: https://mywifequitherjob.com/de-minimis-ended-what-it-means-for-sellers/). Your buyer is the seller still sending individual packages from overseas to US customers, and above all the one sending them by post, where the same source records the damage as severe.

Be honest with yourself about that list. The same source names the losers as Temu, AliExpress dropshippers and foreign postal services, and says the maths on cheap dropshipped goods collapses: a $20 item from China sent by post can land at $100 to $220 once country tariffs and the per-shipment handling fee are added. Some of your best-hurting prospects are leaving the market, not buying software. So qualify on one question in the first call: at your prices, does the customer still buy once duty is on the invoice? If the answer is no, that seller is not a customer, however loudly they are suffering.

# Three dated events that open the conversation

**1 March 2026.** Packages sent by post moved off a flat charge of $80 to $200 per item and onto full value-based tariffs, set by the product and where it was made (source: https://blogs.tradlinx.com/global-de-minimis-exemption-ends-suddenly-the-biggest-u-s-trade-shock-since-section-301/). A flat charge needs no paperwork skill. A value-based duty needs the right product code and declared value on every single item. That change, not the end of the exemption itself, is what makes a per-parcel filing service worth paying for. Lead with it.

**31 July 2026.** Amazon's own warehousing programme tightened which products it will accept, on size and weight (source: https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/). Sellers pushed out of it are re-planning how they get stock into the US right now. That is a warm list with a date on it.

**13 August 2026.** The US Court of International Trade upheld the early end of the exemption (source: https://mezha.net/eng/bukvy/18a803db_us_trade_court/). Use this the moment a prospect says "this will get reversed, I'll wait it out." Say plainly what the same ruling says: Congress still has its own final phase-out planned, and the timing of that is not settled.

# Where to find them

Go where the sources say sellers are already heading. The shift is towards bulk importing, US warehousing and third-party fulfilment (source: https://ufreight.com/us-de-minimis-ends-why-us-3pl-warehousing-matters-for-cross-border-ecommerce/). So the warehouse and fulfilment firms serving China-sourced sellers are sitting on exactly your list.

Pitch them on the traffic they cannot take: the orders their clients still ship direct from overseas. Do not pretend the interests line up perfectly — a client who fully moves to their warehouse stops needing you. Say that out loud in the meeting; it is why they will take the call.

Second list: postal operators across Europe and Asia-Pacific suspended US shipments rather than handle the new requirements (source: https://www.fashionindex.com/blog/de-minimis-ended). Their commercial customers are stranded and identifiable.

# What you say, and what you must not promise

One sentence: we put the right product code and value on every parcel you send to the US, and file it, so it clears.

Be careful with liability, because sellers will push you there in the first call. The importer is expected to use reasonable care in classifying and valuing goods, and penalties fall on the importer for failing it; there are criminal penalties for false information too (source: the Wikipedia entry for US Customs and Border Protection). Treat that as a lead, not as settled wording — get a licensed customs broker to confirm the exact position before you print any promise about who carries the risk. Until then, sell the work and the accuracy, and say nothing about assuming their legal responsibility.

# Price, and the one number that sells for you

The per-parcel fee this plan assumes — one to three dollars per released parcel — is an assumption, unverified. Nothing in the evidence sets a market price for this, because the service does not exist yet. So test it as a price, not as a fact: quote three tiers to your first ten prospects and record which they sign.

What actually closes deals is your error rate on product codes, because that is what decides whether their goods move. Publish it from day one and have a licensed broker check a sample of your filings before you publish anything. A rate you can show beats every claim you can make.

# What kills this channel

**Customers graduating away.** The documented direction of travel is towards bulk import and a US warehouse (source: ufreight, above). Every customer you win is a customer being pulled towards not needing you. Price and plan for it.

**Carriers absorbing the job.** Sellers already using the big carriers report little change. If a carrier folds filing into the shipping label, your warehouse partners become rivals — assumption, unverified. The check is cheap: ask each of your first twenty prospects what their carrier already does for them, and log the answers.