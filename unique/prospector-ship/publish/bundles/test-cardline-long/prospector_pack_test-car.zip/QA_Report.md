# FuelClaim — reclaim fuel duty for small fleets

_Confidence below is on a 0 to 1 scale: 0 means no retrieved passage spoke to the check either way, and 1 means the retrieved passages settled it outright._

_SaaS to reclaim fuel duty for fleets_

## ✅ PASS

_This cleared every check we hold it to, on evidence we fetched and cited below._

### Why this is possible now
2024 HMRC rule change

---
## What we checked

### ✅ Is the problem real?

**Yes — the sources back this.** Confidence 0.80. *(check: `pain_reality`)*

grounded

### ✅ Will this still be worth money later?

**Yes — the sources back this.** Confidence 0.80. *(check: `value_durability`)*

grounded

---
## How it scored

**Overall: 4.2000** (each line is rated out of 5, then weighted)

| What we rated | Score | Why |
|---------------|------:|-----|
| How badly it hurts (`pain_acuity`) | 4/5 | Test justification |
| How provable the money is (`money_provability`) | 4/5 | Test justification |
| How much one person can automate (`automatability`) | 4/5 | Test justification |
| How easy buyers are to reach (`distribution`) | 4/5 | Test justification |
| How hard it is to copy (`defensibility`) | 4/5 | Test justification |
| How buildable it is (`build_feasibility`) | 4/5 | Test justification |

---
## Why this passed

Survived all gates; composite 4.2.

---
## Every source we used

Every claim above traces back to one of these. Follow any of them and check us.

---
## Run details

- **Persona:** <MagicMock name='mock.persona' id='4545429584'>
- **Judged by:** test-model
- **Candidate ID:** `test-cardline-long`
- **Created:** 2026-06-15T00:00:00Z
- **Evidence goes stale after:** 2026-07-15T00:00:00Z