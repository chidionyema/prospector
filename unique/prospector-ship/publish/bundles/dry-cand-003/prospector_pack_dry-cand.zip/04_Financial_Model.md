> Every figure below is computed by Python from the assumptions listed at the end of this document. No language model performed any calculation, so the arithmetic is exact — the arithmetic, not the assumptions. Read those before you rely on any number here.

Revenue: $4,900 per month. Costs: $1,200 per month.