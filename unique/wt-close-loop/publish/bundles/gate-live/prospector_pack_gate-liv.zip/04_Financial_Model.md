> All figures below are computed by Python from verified inputs. No language model performed any calculation, so the arithmetic is exact.

Test financial model content