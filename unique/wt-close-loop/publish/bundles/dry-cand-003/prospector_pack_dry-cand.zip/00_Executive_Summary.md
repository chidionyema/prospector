# Executive summary — AI Fuel Duty Automation

SaaS to reclaim fuel duty for fleets

## Start here — the next ten minutes

1. Open **QA_Report.md** and pick any claim marked SUPPORTED.
2. Click its source link and find the sentence the claim rests on.
3. If the source does not say what we say it says, stop reading and claim the refund — the pack is wrong and you should not build on it.

That is the whole point of the pack: it is checkable. **05_First_Week_Checklist.md** is what to do once it checks out.

## Grounded signals

- **pain reality:** grounded
- **value durability:** grounded

## What this pack does not claim

No unsourced TAM/SAM figures, guaranteed revenue, or legality shortcuts. If a check was unverifiable, it is absent here on purpose.