> All figures below are computed by Python from verified inputs. No language model performed any calculation, so the arithmetic is exact.

Revenue: $4,900 per month. Costs: $1,200 per month.