# Pass Biz

_Confidence below is on a 0 to 1 scale: 0 means no retrieved passage spoke to the check either way, and 1 means the retrieved passages settled it outright._

_A passing business_

## ✅ PASS

_This cleared every check we hold it to, on evidence we fetched and cited below._

---
## What we checked

### ✅ Is the problem real?

**Yes — the sources back this.** Confidence 0.90. *(check: `pain_reality`)*

OK

### ✅ Will this still be worth money later?

**Yes — the sources back this.** Confidence 0.90. *(check: `value_durability`)*

OK

---
## How it scored

**Overall: 4.0000** (each line is rated out of 5, then weighted)

| What we rated | Score | Why |
|---------------|------:|-----|
| How badly it hurts (`pain_acuity`) | 4/5 | good |
| How provable the money is (`money_provability`) | 4/5 | good |
| How much one person can automate (`automatability`) | 4/5 | good |
| How easy buyers are to reach (`distribution`) | 4/5 | good |
| How hard it is to copy (`defensibility`) | 4/5 | good |
| How buildable it is (`build_feasibility`) | 4/5 | good |

---
## Why this passed

---
## Run details

- **Judged by:** test-model
- **Candidate ID:** ` `
- **Created:** 2026-06-13T12:00:00Z