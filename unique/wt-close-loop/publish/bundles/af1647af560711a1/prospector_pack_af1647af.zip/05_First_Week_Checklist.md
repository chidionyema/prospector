# First-week checklist — Pass Biz

Claim-safe starter steps. Adapt only where your own evidence supports it.

1. Re-read the QA report kill/pass gates and list every SUPPORTED citation URL.
2. Confirm the buyer (`who_pays`) matches reality for your market — dossier says: the stated buyer.
3. Sketch the smallest paid offer described in the build spec (no scope creep).
4. Pick one distribution channel from the GTM plan; ignore the rest for week one.
5. Write the first outreach / listing using only claims that survived claim-check.
6. Log what you could not verify; do not invent substitutes.